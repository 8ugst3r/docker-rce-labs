<?php if ( ! defined( 'ABSPATH' ) ) exit;

return array(
	'choice_callbacks240' => 'choice_callbacks240',
);
